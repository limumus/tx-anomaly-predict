"use client";

import Link from "next/link";
import { Twitter, Linkedin, Github, Mail } from "lucide-react";
import { useTheme } from "next-themes";

const footerLinks = [
  {
    title: "Products",
    links: [
      { name: "DeepSearch", href: "/deepsearch" },
      { name: "Reader", href: "/reader" },
      { name: "Embeddings", href: "/embeddings" },
      { name: "Reranker", href: "/reranker" },
      { name: "API Documentation", href: "https://docs.example.com" },
    ],
  },
  {
    title: "Resources",
    links: [
      { name: "Documentation", href: "/docs" },
      { name: "Tutorials", href: "/tutorials" },
      { name: "Blog", href: "/blog" },
      { name: "Community", href: "/community" },
    ],
  },
  {
    title: "Legal",
    links: [
      { name: "Privacy Policy", href: "/privacy" },
      { name: "Terms of Service", href: "/terms" },
      { name: "Cookie Policy", href: "/cookies" },
    ],
  },
];

const socialLinks = [
  { icon: <Twitter className="h-4 w-4" />, href: "https://twitter.com" },
  { icon: <Linkedin className="h-4 w-4" />, href: "https://linkedin.com" },
  { icon: <Github className="h-4 w-4" />, href: "https://github.com" },
  { icon: <Mail className="h-4 w-4" />, href: "mailto:example@example.com" },
];

export function Footer() {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <footer className={`pt-16 pb-8 border-t ${isDark ? 'bg-black text-zinc-400 border-zinc-900' : 'bg-white text-zinc-600 border-zinc-200'}`}>
      <div className="container px-4 mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {footerLinks.map((section) => (
            <div key={section.title} className="space-y-4">
              <h3 className={`text-sm uppercase tracking-wider mb-4 ${isDark ? 'text-white' : 'text-zinc-900'}`}>
                {section.title}
              </h3>
              <ul className="space-y-3">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className={`hover:underline flex items-center ${isDark ? 'hover:text-white' : 'hover:text-zinc-900'}`}
                    >
                      {link.icon && link.icon}
                      {link.name}
                      {link.icon && !link.icon.props.className.includes("mr-") && ""}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 pt-8 border-t flex flex-col md:flex-row justify-between items-center gap-6 border-zinc-800">
          <div className="flex space-x-6">
            {socialLinks.map((link, i) => (
              <Link
                key={`social-${i}`}
                href={link.href}
                className={`${isDark ? 'text-zinc-500 hover:text-white' : 'text-zinc-400 hover:text-zinc-900'} transition-colors`}
                target="_blank"
                rel="noopener noreferrer"
              >
                {link.icon}
              </Link>
            ))}
          </div>
          <div className={isDark ? 'text-zinc-500' : 'text-zinc-400'}>
            © 2025 Search Demo. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}
