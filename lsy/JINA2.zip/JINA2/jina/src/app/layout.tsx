import type { Metadata } from "next";
import "./globals.css";
import { ClientBody } from "./ClientBody";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { ThemeProvider } from "@/components/ThemeProvider";

export const metadata: Metadata = {
  title: "Jina AI - Your Search Foundation, Supercharged.",
  description: "Best-in-class embeddings, rerankers, web crawler scraper, deepsearch, small LMs. The search AI for multilingual and multimodal data.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-screen">
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={true}
        >
          <ClientBody>
            <Navbar />
            <div className="pt-16">
              {children}
            </div>
            <Footer />
          </ClientBody>
        </ThemeProvider>
      </body>
    </html>
  );
}
