import { HeroSection } from "@/components/sections/HeroSection";
import { ProductsSection } from "@/components/sections/ProductsSection";
import { SearchSection } from "@/components/sections/SearchSection";

export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white">
      <HeroSection />
      <ProductsSection />
      <div id="search">
        <SearchSection />
      </div>
    </main>
  );
}
